"""
lordmatrixoid_module
An example python library.
"""

__version__ = "1.0"
__author__ = 'Lord Matrixoid'